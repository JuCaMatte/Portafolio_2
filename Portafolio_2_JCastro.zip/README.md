# ENTREGABLE MÓDULO 3 (PORTAFOLIO 2)

## DESCRIPCIÓN DEL PROYECTO
En el contexto del Portafolio 1, de una tienda de e-commerce, en este caso una librería : "Tu Librería".
Se con tinúa con este Portafolio 2, que consiste en desarrollar la lógica de un carro de compras de la
librería. El carro de compras permite agregar, quitar libros del carrito, aplicar descuentos y sumar el
total de los libros en el carro.

## NUEVAS CARACTERÍSTICAS


## USUARIOS POR DEFECTO

nombre: "Pedro", password: "123456"
nombre: "Carlos", password: "123456

### Deployment
Se pone a disposición de los usuarios una Github page, para que prueben el funcionamiento de la página.
En la página estarán a disposición: [Portafolio-2]<https://jucamatte.github.io/Portafolio-2/>
## REQUERIMIENTOS


## TECNOLOGÍAS UTILIZADAS

* [Bootstrap5](https://getbootstrap.com) - Bootstrap
* [JavaScript](https://www.javascript.com/) - JavaScript
* [HTML5](https://developer.mozilla.org/es/docs/Glossary/HTML5/) - Tutorial HTML-5
* [CSS3](https://developer.mozilla.org/es/docs/Web/CSS/) - Tutorial CSS

## Autor
**Juan Castro M.** - _Portafolio 2_ - [JuCaMatte](https://github.com/JuCaMatte)
